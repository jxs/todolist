var todo = Backbone.Model.extend({
    
    defaults: {
	id : "random",
	content:"blank",
	geolocation:{latitude:0,longitude:0},
	done: false
    },
    initialize:function(){
	      if (!this.get("geolocation")) {
        this.set({"geolocation": this.defaults.geolocation});
      }
    },
    toggle:function(){
	this.set({done: !this.get("done")})
    },
   clear: function() {
      this.destroy();
   },
    store:function(){
	
    }
})
var todolist = Backbone.Collection.extend({
    model:todo,
    localStorage: new Backbone.LocalStorage("todolist"),
    initialize:function(){

    },
    done: function() {
	return this.filter(function(todo){ return todo.get('done'); });
    },
    remaining: function() {
      return this.without.apply(this, this.done());
    },
   nextOrder: function() {
      if (!this.length) return 1;
      return this.last().get('id') + 1;
    },
    comparator: function(todo) {
      return todo.get('id');
    } 
})
//instanciar a coleção para puder ser usada no view
var Todolist = new todolist;

var todoview = Backbone.View.extend({
    tagName: 'li',
    //template: _.template($('#item-template').html()),
    events: {
	"click .check" : "toggleDone"},
    initialize: function(){
	//observers do view no mode, quando model remove, o view tambem vai remover
	_.bindAll(this, 'render', 'close', 'clear');
	this.model.on('change', this.render);
	this.model.on('destroy', this.clear);
    },
    render: function() {
	var template= _.template($('#item-template').html());
	this.$el.html(template(this.model.toJSON()));
	//this.input = this.$('.todo-input');
	return this
    },
    close: function() {
	this.model.save({content: this.input.val()});	
    },
    toggleDone: function() {
	this.model.clear();
    },
    edit : function(){
	this.input.focus();
    },
    clear:function(){
	console.log("hello");
	this.remove();
	this.unbind();
    }
})
var Appview = Backbone.View.extend({
    el:$("#todo-app"),
    events:{
	"keypress #todo-input" : "checkIfEnter"},
    initialize:function(){
	//observers do view principal ao model
	_.bindAll(this, 'addOne','addAll');
	Todolist.on('reset',   this.addAll);
	Todolist.on('add',this.addOne);
	Todolist.fetch();
    },
    checkIfEnter:function(e){
	if (e.keyCode != 13) return;
	this.createtodo();
    },
    getstats:function(){
	var geo;
	navigator.geolocation.getCurrentPosition(function(loc){geo ={'latitude':loc.coords.latitude,'longitude':loc.coords.longitude}});
	var id = Todolist.nextOrder();
	var content = this.$("#todo-input").val();
	done = false
	return {id:id,geolocation:geo,content:content};
    },
   addOne: function(todo) {
       var view = new todoview({model: todo});
       this.$("#todo-list").append(view.render().el);
   },
    addAll:function(){
	Todolist.each(this.addOne);
    },
    createtodo:function(){
	Todolist.create(this.getstats());
	this.$("#todo-input").val("");
    }

})
var App;
window.onload =function(){App = new Appview({el:$("#todo-app")})};